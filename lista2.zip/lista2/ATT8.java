package lista2;

//Implemente um programa que leia um valor inicial A e imprima a sequência de valores do cálculo de A! e o seu resultado. Ex: 5! = 5 ∗ 4 ∗ 3 ∗ 2 ∗ 1 =120

import java.util.Scanner;

public class ATT8 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.print("Digite um número inteiro positivo: ");
	        int a = scanner.nextInt();
	        
	        while (a < 0) {
	            System.out.println("Número inválido. Digite novamente.");
	            System.out.print("Digite um número inteiro positivo: ");
	            a = scanner.nextInt();
	        }
	        
	        int num = 1;
	        String seq = a + "! = ";
	        
	        for (int i = a; i >= 1; i--) {
	            num *= i;
	            seq += i;
	            if (i > 1) {
	                seq += " * ";
	            }
	        }
	        
	        System.out.println(seq + " = " + num);
	    }
	}


