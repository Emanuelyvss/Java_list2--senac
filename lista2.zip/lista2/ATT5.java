package lista2;

//Implemente um programa que leia uma quantidade não determinada de números positivos. Calcule a quantidade de números pares e ímpares, a média de valores pares e a
//média geral dos números lidos. O número que encerrará a leitura será zero.

import java.util.Scanner;

public class ATT5 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        int quantPares = 0;
	        int quantImpares = 0;
	        int somaPares = 0;
	        int quantTotal = 0;
	        int numero = 0;
	        
	        do {
	            System.out.print("Digite um número (zero para sair): ");
	            numero = scanner.nextInt();
	            
	            if (numero != 0) {
	                if (numero % 2 == 0) {
	                    quantPares++;
	                    somaPares += numero;
	                } else {
	                    quantImpares++;
	                }
	                
	                quantTotal++;
	            }
	        } while (numero != 0);
	        
	        double mediaPares = 0;
	        if (quantPares > 0) {
	            mediaPares = (double) somaPares / quantPares;
	        }
	        
	        double mediaTotal = 0;
	        if (quantTotal > 0) {
	            mediaTotal = (double) (somaPares + quantImpares) / quantTotal;
	        }
	        
	        System.out.printf("Quantidade de pares: %d\n", quantPares);
	        System.out.printf("Quantidade de ímpares: %d\n", quantImpares);
	        System.out.printf("Média de valores pares: %.2f\n", mediaPares);
	        System.out.printf("Média geral: %.2f\n", mediaTotal);
	    }
	}


