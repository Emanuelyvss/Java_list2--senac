package lista2;

// Implemente um programa que gera e escreve os números ímpares entre 100 e 200.

import java.util.Scanner;

public class ATT6 {
	    public static void main(String[] args) {
	        for (int i = 101; i < 200; i += 2) {
	            System.out.println(i);
	        }
	    }
	}


