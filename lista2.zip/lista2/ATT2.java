package lista2;

//Desenvolver um algoritmo que leia a altura de 15 pessoas. Este programa deverá calcular e mostrar:
// A menor altura do grupo; A maior altura do grupo.

import java.util.Scanner;

public class ATT2 {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        double menorAlt = Double.MAX_VALUE;
	        double maiorAlt = Double.MIN_VALUE;
	        double altura;
	        for (int i = 1; i <= 15; i++) {
	            System.out.printf("Digite a altura da pessoa %d: ", i);
	            altura = sc.nextDouble();
	            if (altura < menorAlt) {
	                menorAlt = altura;
	            }
	            if (altura > maiorAlt) {
	                maiorAlt = altura;
	            }
	        }
	        System.out.println("A menor altura do grupo é: " + menorAlt);
	        System.out.println("A maior altura do grupo é: " + maiorAlt);
	    }
	}


