package lista2;

// Implemente um programa que leia uma quantidade desconhecida de números e conte quantos deles estão nos seguintes intervalos:
//[0-25], [26-50], [51-75] e [76-100]. A entrada de dados deve terminar quando for lido um número negativo.

import java.util.Scanner;

public class ATT4 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        int[] intervalos = new int[4]; // contador de cada intervalo
	        
	        int numero = 0;
	        do {
	            System.out.print("Digite um número (negativo para sair): ");
	            numero = scanner.nextInt();
	            
	            if (numero >= 0 && numero <= 25) {
	                intervalos[0]++;
	            } else if (numero >= 26 && numero <= 50) {
	                intervalos[1]++;
	            } else if (numero >= 51 && numero <= 75) {
	                intervalos[2]++;
	            } else if (numero >= 76 && numero <= 100) {
	                intervalos[3]++;
	            }
	        } while (numero >= 0);
	        
	        System.out.printf("Intervalo [0-25]: %d\n", intervalos[0]);
	        System.out.printf("Intervalo [26-50]: %d\n", intervalos[1]);
	        System.out.printf("Intervalo [51-75]: %d\n", intervalos[2]);
	        System.out.printf("Intervalo [76-100]: %d\n", intervalos[3]);
	    }
	}


