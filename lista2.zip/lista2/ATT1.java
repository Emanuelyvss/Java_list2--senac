package lista2;

//Desenvolver um algoritmo que efetue a soma de todos os números ímpares que são
//múltiplos de três e que se encontram no conjunto dos números de 1 até 500.

import java.util.Scanner;

public class ATT1 {
	    public static void main(String[] args) {
	        int soma = 0;
	        for (int i = 1; i <= 500; i++) {
	            if (i % 2 == 1 && i % 3 == 0) { // verifica se é ímpar e múltiplo de três
	                soma += i; // adiciona o número à variável soma
	            }
	        }
	        System.out.println("A soma dos números ímpares múltiplos de três entre 1 e 500 é: " + soma);
	    }
	}


