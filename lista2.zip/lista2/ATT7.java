package lista2;

//Implemente um programa que leia um valor para uma variável N de 1 a 10 e calcule a tabuada de N. Mostre a tabuada na forma: 
//0 ∗ N = 0, 1 ∗ N = 1N, 2 ∗ N = 2N, · · · , 10 ∗ N = 10N.

import java.util.Scanner;

public class ATT7 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.print("Digite um número entre 1 e 10: ");
	        int n = scanner.nextInt();
	        
	        while (n < 1 || n > 10) {
	            System.out.println("Número inválido. Digite novamente.");
	            System.out.print("Digite um número entre 1 e 10: ");
	            n = scanner.nextInt();
	        }
	        
	        for (int i = 0; i <= 10; i++) {
	            int resultado = i * n;
	            System.out.printf("%d * %d = %d\n", i, n, resultado);
	        }
	    }
	}


